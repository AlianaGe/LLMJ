# Level: api, webui > chat, eval, train > data, model > extras, hparams

from .cli import VERSION


__version__ = VERSION
